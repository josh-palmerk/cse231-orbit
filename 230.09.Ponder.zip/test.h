/***********************************************************************
 * Heaader File:
 *    TEST
 * Author:
 *    Br. Helfrich
 * Summary:
 *    The test runner for all the unit tests
 ************************************************************************/

#pragma once

void testRunner();
